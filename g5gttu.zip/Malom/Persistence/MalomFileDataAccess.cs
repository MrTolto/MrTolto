﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Malom.Persistence
{
    class MalomFileDataAccess : MalomDataAccess
    {
        public async Task<int[]> LoadAsync(String path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    int[] table = new int[54];
                    string line = await reader.ReadLineAsync();
                    string[] numbers = line.Split(' ');
                    table[0] = int.Parse(numbers[0]);
                    table[1] = int.Parse(numbers[1]);
                    table[2] = int.Parse(numbers[2]);
                    table[3] = int.Parse(numbers[3]);
                    table[4] = int.Parse(numbers[4]);

                    line = await reader.ReadLineAsync();
                    numbers = line.Split(' ');

                    for (int i = 0; i < 49; i++)
                    {
                        table[i + 5] = int.Parse(numbers[i]);
                    }
                    return table;
                }
            }
            catch
            {
                throw new MalomException();
            }
        }
        public async Task SaveAsync(string path, int[] table)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(path))
                {
                    await writer.WriteLineAsync(table[0] + " " + table[1] + " " + table[2] + " " + table[3] + " " + table[4]);
                    for (int i = 0; i < 49; i++)
                    {
                        await writer.WriteAsync(table[i + 5] + " ");
                    }
                    await writer.WriteLineAsync();
                }
            }
            catch
            {
                throw new MalomException();
            }

        }
    }
}
