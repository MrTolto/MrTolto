﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Malom.Persistence
{
    public interface MalomDataAccess
    {
        Task<int[]> LoadAsync(string path);
        Task SaveAsync(string path, int[] table);
    }
}
