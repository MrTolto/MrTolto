﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Malom.Persistence
{
    class MalomException : Exception
    {
        public MalomException() { }
    }
}
