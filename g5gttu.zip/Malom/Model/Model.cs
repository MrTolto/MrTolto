﻿using System;
using System.Collections.Generic;
using System.Text;
using Malom.Persistence;
using System.Threading.Tasks;
using System.Linq;

namespace Malom.Model
{
    public class MalomModel
    {

        //Signals
        public event EventHandler<int> RefreshTable;
        public event EventHandler<int> GameOver;


        //Adattagok

        private MalomDataAccess _dataAccess;
        private int _numberOfRedUnits;
        private int _numberofBlueUnits;
        private int[,] _table = new int[7, 7];
        private int _firstStageSteps;
        private int _currentPlayer; // 0 Red 1 Blue
        private int _stepStage;
        private int _Stage1X;
        private int _Stage1Y;
        private bool isFirstRefresh = true;

        //Propertys

        public int CurrentPlayer
        {
            get
            {
                return _currentPlayer;
            }
        }

        public int[,] Table
        {
            get
            {
                return _table;
            }
        }

        // ezek csak a teszthez kellenek

        public int StepStage
        {
            get
            { return _stepStage; }
        }

        public int firstStepStage
        {
            get
            {
                return _firstStageSteps;
            }
        }

        public int numberOfBlueUnits
        {
            get
            {
                return _numberofBlueUnits;
            }
        }

        public int numberOfRedUnits
        {
            get
            {
                return _numberOfRedUnits;
            }
        }

        //konstruktor

        public MalomModel(MalomDataAccess a)
        {
            RestartGame();
            _dataAccess = a;
        }
        public MalomModel(int[,] tmp, int fst, int cp, int nR, int nB, int ss)
        {
            _table = tmp;
            _firstStageSteps = fst;
            _currentPlayer = cp;
            _numberofBlueUnits = nB;
            _numberOfRedUnits = nR;
            _stepStage = ss;
        }


        //Metódusok

        public async Task LoadGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");
            int[] tmp = await _dataAccess.LoadAsync(path);
            _numberofBlueUnits = tmp[0];
            _numberOfRedUnits = tmp[1];
            _firstStageSteps = tmp[2];
            _currentPlayer = tmp[3];
            _stepStage = tmp[4];

            if (_numberofBlueUnits == 0) _numberofBlueUnits = 9;
            if (_numberOfRedUnits == 0) _numberOfRedUnits = 9;
            if (_currentPlayer == 0) _currentPlayer = 9;


            for (int i = 0; i < 49; i++)
            {
                _table[i / 7, i % 7] = tmp[i + 5];
            }

            RefreshTable.Invoke(this, 1);
        }

        public async Task SaveGameAsnyc(string path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access provided.");

            int[] tmp = new int[54];
            tmp[0] = _numberofBlueUnits;
            tmp[1] = _numberOfRedUnits;
            tmp[2] = _firstStageSteps;
            tmp[3] = _currentPlayer;
            tmp[4] = _stepStage;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    tmp[i * 7 + j + 5] = _table[i, j];
                }
            }
            await _dataAccess.SaveAsync(path, tmp);
        }

        public void SkipTurn()
        {
            if (_firstStageSteps == 0 || _stepStage == 2)
            {
                _stepStage = 0;
                _currentPlayer = _currentPlayer == 1 ? 2 : 1;
            }
        }

        public void RestartGame()
        {
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    _table[i, j] = 0;
                }
            }


            _firstStageSteps = 18;
            _numberofBlueUnits = 9;
            _numberOfRedUnits = 9;
            _currentPlayer = 1;
            _stepStage = 0;
            init();
            if (!isFirstRefresh)
                RefreshTable(this, 1);
            else
                isFirstRefresh = false;

        }



        private void init()
        {
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if ((i != j) & (i + j != 6) & (i != 3) & (j != 3))
                    {
                        _table[i, j] = -1;
                    }
                }
            }
            _table[3, 3] = -1;

        }


        private bool CheckNextUnitStep(int x, int y, int Player, int PrevX, int PrevY) // 1 up, 2 right, 3 down, 4 left <Direction>
        {
            int direction = 0;
            if (x > PrevX) direction = 1;
            if (x < PrevX) direction = 3;
            if (y > PrevY) direction = 4;
            if (y < PrevY) direction = 2;


            bool tmp = false;
            int counter = 0;
            switch (direction)
            {
                case 1:
                    for (int i = x; i >= 0; i--)
                    {
                        counter++;
                        if (_table[i, y] == Player)
                        {
                            tmp = true;
                        }
                        if (counter == 4 || (_table[i, y] != -1 && i != x) || (y == 3 && i == 3) || tmp) break;
                    }
                    break;
                case 2:
                    for (int i = y; i < 7; i++)
                    {
                        counter++;
                        if (_table[x, i] == Player)
                        {
                            tmp = true;
                        }
                        if (counter == 4 || (_table[x, i] != -1 && i != y) || (i == 3 && x == 3) || tmp) break;
                    }
                    break;
                case 3:
                    for (int i = x; i < 7; i++)
                    {
                        counter++;
                        if (_table[i, y] == Player)
                        {
                            tmp = true;
                        }
                        if (counter == 4 || (_table[i, y] != -1 && i != x) || (y == 3 && i == 3) || tmp) break;
                    }
                    break;
                case 4:
                    for (int i = y; i >= 0; i--)
                    {
                        counter++;
                        if (_table[x, i] == Player)
                        {
                            tmp = true;
                        }
                        if (counter == 4 || (_table[x, i] != -1 && i != y) || (i == 3 && x == 3) || tmp) break;
                    }
                    break;
            }
            return tmp;
        }

        private bool isThereAnyMill(int x, int y, int Player)
        {
            int i;
            int counter = 0;
            for (i = 0; i < 7; i++)
            {
                if (_table[i, y] == Player)
                    counter++;
                if (i == 3 && y == 3)
                    break;
            }
            if (counter == 3 && i >= x) return true;
            counter = 0;

            for (i = 6; i >= 0; i--)
            {
                if (_table[i, y] == Player)
                    counter++;
                if (i == 3 && y == 3)
                    break;
            }
            if (counter == 3 && i <= x) return true;
            counter = 0;

            for (i = 0; i < 7; i++)
            {
                if (_table[x, i] == Player)
                    counter++;
                if (i == 3 && x == 3)
                    break;
            }
            if (counter == 3 && i >= y) return true;
            counter = 0;

            for (i = 6; i >= 0; i--)
            {
                if (_table[x, i] == Player)
                    counter++;
                if (i == 3 && x == 3)
                    break;
            }
            if (counter == 3 && i <= y) return true;
            counter = 0;

            return false;
        }

        public bool DestroyUnit(int x, int y, int Player)
        {
            if (_table[x, y] != 0 && !isThereAnyMill(x, y, _table[x, y]) && _table[x, y] != Player)
            {
                _table[x, y] = 0;
                if (Player == 1)
                    _numberofBlueUnits--;
                else
                    _numberOfRedUnits--;

                _stepStage = 0;

                return true;
            }
            else
                return false;

        }

        public void StepGameFirstStage(int x, int y)
        {
            if (x < 7 && y < 7)
            {
                if (_firstStageSteps > 0 && _stepStage != 2)
                {

                    if (_table[x, y] == 0)
                    {
                        _table[x, y] = _currentPlayer;
                        _firstStageSteps--;
                        if (isThereAnyMill(x, y, Table[x, y]))
                            _stepStage = 2;
                        else
                            _currentPlayer = _currentPlayer == 1 ? 2 : 1;
                    }

                }
                else
                {
                    if (_stepStage == 2)
                    {
                        if (DestroyUnit(x, y, _currentPlayer))
                            _currentPlayer = _currentPlayer == 1 ? 2 : 1;
                    }

                    else if (_stepStage == 1)
                    {
                        _stepStage = 0;
                        if (_table[x, y] == 0 && (x == _Stage1X || y == _Stage1Y))
                        {
                            if (CheckNextUnitStep(x, y, _currentPlayer, _Stage1X, _Stage1Y))
                            {
                                _table[_Stage1X, _Stage1Y] = 0;
                                _table[x, y] = _currentPlayer;

                                if (isThereAnyMill(x, y, _currentPlayer))
                                    _stepStage = 2;
                                else
                                {
                                    _stepStage = 0;
                                    _currentPlayer = _currentPlayer == 1 ? 2 : 1;
                                }
                            }

                        }
                    }
                    else if (_stepStage == 0)
                    {
                        if (_table[x, y] == _currentPlayer)
                        {
                            _stepStage = 1;
                            _Stage1X = x;
                            _Stage1Y = y;
                        }
                    }
                }
            }
            if (RefreshTable != null)
                RefreshTable.Invoke(this, 1);
            isGameOver();

        }


        public void isGameOver() // teszt miatt public csak
        {
            if (_numberofBlueUnits < 3)
            {
                if (GameOver != null)
                    GameOver.Invoke(this, 1);
            }

            if (_numberOfRedUnits < 3)
            {
                if (GameOver != null)
                    GameOver.Invoke(this, 2);
            }

        }



    }
}
