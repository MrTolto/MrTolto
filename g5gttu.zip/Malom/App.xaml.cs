﻿using Malom.ViewModel;
using Malom.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Malom.Persistence;
using Microsoft.Win32;

namespace Malom
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private MalomViewModel _viewModel;
        private MainWindow _window;
        private MalomModel _model;

        App()
        {
            this.Startup += this.App_Startup;
        }

        void App_Startup(object sender, StartupEventArgs eventArgs)
        {

            _model = new MalomModel(new MalomFileDataAccess());
            _model.GameOver += new EventHandler<int>(GameOver);

            _viewModel = new MalomViewModel(_model);
            _viewModel.NewGame += new EventHandler(ViewModel_NewGame);
            _viewModel.ExitGame += new EventHandler(ViewModel_ExitGame);
            _viewModel.LoadGame += new EventHandler(ViewModel_LoadGame);
            _viewModel.SaveGame += new EventHandler(ViewModel_SaveGame);


            _window = new MainWindow();
            _window.DataContext = _viewModel;
            _window.Show();
        }

        private void ViewModel_NewGame(object sender, EventArgs e)
        {
            _model.RestartGame();
        }

        /// <summary>
        /// Játék betöltésének eseménykezelője.
        /// </summary>
        private async void ViewModel_LoadGame(object sender, System.EventArgs e)
        {

            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog(); // dialógusablak
                openFileDialog.Title = "Sudoku tábla betöltése";
                openFileDialog.Filter = "Sudoku tábla|*.stl";
                if (openFileDialog.ShowDialog() == true)
                {
                    // játék betöltése
                    await _model.LoadGameAsync(openFileDialog.FileName);

                }
            }
            catch (MalomException)
            {
                MessageBox.Show("A fájl betöltése sikertelen!", "Sudoku", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        /// <summary>
        /// Játék mentésének eseménykezelője.
        /// </summary>
        private async void ViewModel_SaveGame(object sender, EventArgs e)
        {

            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog(); // dialógablak
                saveFileDialog.Title = "Sudoku tábla betöltése";
                saveFileDialog.Filter = "Sudoku tábla|*.stl";
                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        // játéktábla mentése
                        await _model.SaveGameAsnyc(saveFileDialog.FileName);
                    }
                    catch (MalomException)
                    {
                        MessageBox.Show("Játék mentése sikertelen!" + Environment.NewLine + "Hibás az elérési út, vagy a könyvtár nem írható.", "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("A fájl mentése sikertelen!", "Sudoku", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        /// <summary>
        /// Játékból való kilépés eseménykezelője.
        /// </summary>
        private void ViewModel_ExitGame(object sender, System.EventArgs e)
        {
            _window.Close(); // ablak bezárása
        }


        private void GameOver(object sender, int e)
        {

            
                MessageBox.Show("A győztés játékos: " + ((e == 1) ? "Piros" : "Kék"),
                                "Malom játék",
                                MessageBoxButton.OK,
                                MessageBoxImage.Asterisk);
            
        }
    }
}
