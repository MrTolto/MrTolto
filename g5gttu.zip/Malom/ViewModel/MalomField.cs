﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;

namespace Malom.ViewModel
{
    class MalomField : ViewModelBase
    {
        private SolidColorBrush _color;
        private Visibility _enabled;
        private int size = 28;



        public Visibility ButtonVisibility
        { 
            get
            { return _enabled; }
            set
            {
                _enabled = value;
                OnPropertyChanged();
            }
        }

        public Int32 X { get; set; }

        public Int32 Y { get; set; }

        public int Size
        {
            get { return size; }
            private set { }
        }
        public int Number
        { get; set; }


        public SolidColorBrush ButtonColor
        {
            get { return _color; }
            set 
            {
                _color = value;
                OnPropertyChanged();
            }
        }


        public DelegateCommand ButtonCommand { get; set; }
    }
}
