﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Media;
using Malom.Model;

namespace Malom.ViewModel
{
    class MalomViewModel : ViewModelBase
    {
        private MalomModel _model;
        private ObservableCollection<MalomField> _table;

        ///Events
        ///

        /// <summary>
        /// Új játék eseménye.
        /// </summary>
        public event EventHandler NewGame;

        /// <summary>
        /// Játék betöltésének eseménye.
        /// </summary>
        public event EventHandler LoadGame;

        /// <summary>
        /// Játék mentésének eseménye.
        /// </summary>
        public event EventHandler SaveGame;

        /// <summary>
        /// Játékból való kilépés eseménye.
        /// </summary>
        public event EventHandler ExitGame;


        /// <summary>
        /// Commands
        /// </summary>

        public DelegateCommand NewGameCommand { get; private set; }

        public DelegateCommand LoadGameCommand { get; private set; }

        public DelegateCommand SaveGameCommand { get; private set; }

        public DelegateCommand ExitCommand { get; private set; }

        public DelegateCommand SkipTurnCommand { get; private set; }

        /// <summary>
        /// Properties
        /// </summary>
        public string CurrentPlayer 
        {
            get { return (_model.CurrentPlayer == 1 ? "Red   |   " : "Blue   |   "); }
            private set { }
        }
        public string GameStage
        {
            get
            {
                if (_model.firstStepStage != 0 && _model.StepStage != 2) return "Place";
                else
                    switch (_model.StepStage)
                    {
                        case 0:
                            return "Select";
                        case 1:
                            return "Step";
                        case 2:
                            return "Destroy";
                    }
                return "";
            }

        }

        public ObservableCollection<MalomField> Table
        {
            get
            {
                return _table;
            }
            private set { }
        }

        /// <summary>
        /// Constructors
        /// </summary>
        /// <param name="model"></param>

        public MalomViewModel(MalomModel model)
        {

            

            _model = model;
            _model.RefreshTable += this.UpdateGame;

            NewGameCommand = new DelegateCommand(param => OnNewGame());
            LoadGameCommand = new DelegateCommand(param => OnLoadGame());
            SaveGameCommand = new DelegateCommand(param => OnSaveGame());
            ExitCommand = new DelegateCommand(param => OnExitGame());
            SkipTurnCommand = new DelegateCommand(param => OnSkipTurn());

            _table = new ObservableCollection<MalomField>();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    _table.Add(new MalomField
                    {
                        ButtonColor = new SolidColorBrush(Colors.White),
                        ButtonVisibility = System.Windows.Visibility.Visible,
                        X = i,
                        Y = j,
                        Number = i * 7 + j,
                        ButtonCommand = new DelegateCommand(param => StepGame(Convert.ToInt32(param)))
                    });
                }
            }

            UpdateGame(this, 1);




        }

        ///
        /// Event Handlers
        ///




        ///Event Methods
        
        private void OnNewGame()
        {
            if (NewGame != null)
                NewGame(this, EventArgs.Empty);
        }
        private void OnLoadGame()
        {
            if (LoadGame != null)
                LoadGame(this, EventArgs.Empty);
        }

        private void OnSaveGame()
        {
            if (SaveGame != null)
                SaveGame(this, EventArgs.Empty);
        }

        private void OnExitGame()
        {
            if (ExitGame != null)
                ExitGame(this, EventArgs.Empty);
        }
        
        private void OnSkipTurn()
        {
            _model.SkipTurn();
            OnPropertyChanged("CurrentPlayer");
            OnPropertyChanged("GameStage");
        }

        /// <summary>
        /// Játék léptetése eseménykiváltása.
        /// </summary>
        /// <param name="x">A lépett mező indexe.</param>

        private void StepGame(Int32 x)
        {
            MalomField tmp = _table[x];
            _model.StepGameFirstStage(tmp.X, tmp.Y);

            OnPropertyChanged("CurrentPlayer");
            OnPropertyChanged("GameStage");

        }


        private void UpdateGame(object sender, int a)
        {
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    switch (_model.Table[i, j])
                    {
                        case (-1):
                            _table[i * 7 + j].ButtonColor = new SolidColorBrush(Colors.Transparent);
                            _table[i * 7 + j].ButtonVisibility = System.Windows.Visibility.Hidden;
                            break;
                        case 0:
                            _table[i * 7 + j].ButtonColor = new SolidColorBrush(Colors.White);
                            break;
                        case 1:
                            _table[i * 7 + j].ButtonColor = new SolidColorBrush(Colors.Red);
                            break;
                        case 2:
                            _table[i * 7 + j].ButtonColor = new SolidColorBrush(Colors.Blue);
                            break;
                    }
                }
            }
            

        }
    }
}
