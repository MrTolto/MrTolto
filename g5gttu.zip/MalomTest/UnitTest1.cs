using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Threading.Tasks;
using Malom.Model;
using Malom.Persistence;

namespace MalomTest
{
    [TestClass]
    public class UnitTest1
    {
        private MalomModel _model;
        private int[] table;
        private Mock<MalomDataAccess> _mock;

        [TestInitialize]
        public void Initialize()
        {
            table = new int[54];
            _mock = new Mock<MalomDataAccess>();
            _mock.Setup(_mock => _mock.LoadAsync(It.IsAny<String>())).Returns(() => Task.FromResult(table));

            _model = new MalomModel(_mock.Object);
            _model.RefreshTable += this.Model_RefreshTable;
            _model.GameOver += this.Model_GameOver;
        }
        [TestMethod]
        public void MalomModelNewGameTest()
        {
            _model.RestartGame();
            Assert.AreEqual(1, _model.CurrentPlayer);

            int emptyFields = 0;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if (_model.Table[i, j] == 0)
                    {
                        emptyFields++;
                    }
                }
            }
            Assert.AreEqual(24, emptyFields);


        }

        [TestMethod]
        public void MalomGameModelStepTest()
        {
            Assert.AreEqual(1, _model.CurrentPlayer);
            _model.StepGameFirstStage(0, 0);
            Assert.AreEqual(2, _model.CurrentPlayer);
            Assert.AreEqual(1, _model.Table[0, 0]);

            _model.StepGameFirstStage(0, 0);
            Assert.AreEqual(2, _model.CurrentPlayer);
            Assert.AreEqual(1, _model.Table[0, 0]);

            _model.StepGameFirstStage(1, 0);
            Assert.AreEqual(2, _model.CurrentPlayer);
            Assert.AreEqual(-1, _model.Table[1, 0]);

        }
        [TestMethod]
        public async Task MalomGameLoadTest()
        {
            _model.RestartGame();

            await _model.LoadGameAsync(String.Empty);

            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    Assert.AreEqual(table[i * 7 + j + 5], _model.Table[i, j]);
                }
            }

            _mock.Verify(dataAcces => dataAcces.LoadAsync(String.Empty), Times.Once());
        }
        [TestMethod]
        public void EndGameTest()
        {
            _model.RestartGame();
            int[,] tmpTable = new int[7, 7];
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    tmpTable[i, j] = 0;
                }
            }

            tmpTable[0, 0] = 1;
            tmpTable[0, 3] = 1;
            tmpTable[0, 6] = 1;
            tmpTable[6, 0] = 2;
            tmpTable[6, 3] = 2;
            tmpTable[3, 3] = 2;
            _model = new MalomModel(tmpTable, 0, 1, 3, 3, 2);

            Assert.IsTrue(_model.Table[3, 3] == 2);

            Assert.IsTrue(_model.StepStage == 2);
            _model.StepGameFirstStage(3, 3);
            Assert.IsTrue(_model.Table[3, 3] == 0);
            Assert.IsTrue(_model.StepStage == 0);


        }
        private void Model_RefreshTable(object sender, int e)
        {
            Assert.IsTrue(_model.numberOfBlueUnits > 3 && _model.numberOfRedUnits > 3);
            Assert.IsTrue((_model.firstStepStage == 0) || (_model.firstStepStage > 0 && (_model.StepStage == 0 || _model.StepStage == 2)));
        }

        private void Model_GameOver(object sender, int e)
        {
            Assert.IsTrue(_model.numberOfRedUnits < 3 || _model.numberOfBlueUnits < 3);
            Assert.IsTrue((_model.numberOfBlueUnits < 3 && e == 1) || (_model.numberOfRedUnits < 3 && e == 2));
        }
    }
}
